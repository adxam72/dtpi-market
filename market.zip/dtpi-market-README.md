# DTPI Market — To'liq Web Application

## 🚀 Tezkor ishga tushirish

### 1. O'rnatish
```bash
cd dtpi-market
npm install
```

### 2. Serverni ishga tushirish
```bash
node server.js
```

Server: **http://localhost:3000**

---

## 🌐 URL manzillar

| Sahifa | URL |
|--------|-----|
| 🛍️ Mijozlar bozori | http://localhost:3000 |
| ⚙️ Admin panel | http://localhost:3000/admin.html |

---

## 🔐 Kirish ma'lumotlari

### Admin Panel
- **Login:** `admin`
- **Parol:** `admin123`

### Mijoz
- Ro'yxatdan o'tish orqali (har kim)

---

## 📦 Texnologiyalar

| Qatlam | Texnologiya |
|--------|-------------|
| Backend | Node.js + Express |
| Ma'lumotlar bazasi | NeDB (embedded, faylga yozadi) |
| Auth | JWT (JSON Web Tokens) |
| Frontend | Vanilla HTML/CSS/JS |
| Shriftlar | Fraunces + Plus Jakarta Sans |

---

## 🏗️ Papka tuzilmasi

```
dtpi-market/
├── server.js          # Backend API
├── public/
│   ├── index.html     # Mijozlar interfeysi
│   ├── admin.html     # Admin panel
│   └── logo.jpg       # DTPI logotipi
├── data/              # NeDB bazasi (avtomatik yaratiladi)
│   ├── users.db
│   ├── products.db
│   ├── orders.db
│   ├── reviews.db
│   └── cart.db
└── uploads/           # Rasm yuklash uchun
```

---

## 🔌 API Endpoints

### Auth
- `POST /api/auth/register` — Ro'yxat
- `POST /api/auth/login` — Mijoz kirish
- `POST /api/auth/admin/login` — Admin kirish
- `GET /api/auth/me` — Profil

### Mahsulotlar
- `GET /api/products` — Ro'yxat (filter, sort, search)
- `GET /api/products/:id` — Bittasi
- `POST /api/products` — Qo'shish (Admin)
- `PUT /api/products/:id` — Tahrirlash (Admin)
- `DELETE /api/products/:id` — O'chirish (Admin)

### Sharhlar
- `GET /api/products/:id/reviews` — Sharhlar
- `POST /api/products/:id/reviews` — Sharh qo'shish (Auth)

### Savat
- `GET /api/cart` — Savat
- `POST /api/cart` — Qo'shish
- `PUT /api/cart/:id` — Miqdor
- `DELETE /api/cart/:id` — O'chirish

### Buyurtmalar
- `GET /api/orders` — Ro'yxat
- `POST /api/orders` — Yaratish
- `PUT /api/orders/:id/status` — Status (Admin)

### Admin
- `GET /api/admin/stats` — Statistika
- `GET /api/admin/users` — Foydalanuvchilar

---

## ☁️ Bulutga joylashtirish (Deployment)

### Railway.app (bepul)
1. GitHub'ga yuklang
2. railway.app ga kiring
3. "New Project → Deploy from GitHub"
4. Domain avtomatik beriladi

### Render.com
1. render.com ga kiring
2. "New Web Service"
3. Build Command: `npm install`
4. Start Command: `node server.js`
